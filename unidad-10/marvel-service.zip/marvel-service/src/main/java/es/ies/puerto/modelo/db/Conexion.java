package es.ies.puerto.modelo.db;

import es.ies.puerto.config.AppConfig;
import es.ies.puerto.exception.MarvelException;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion extends AppConfig {
    private Connection con;

    private String url;

    public Conexion() throws MarvelException {
        url = "jdbc:sqlite:" + getUrlBd();
    }

    public Connection getConexion() throws MarvelException {
        try {
            Class.forName("org.sqlite.JDBC");
            this.con = DriverManager.getConnection(url);
        }catch (Exception exception) {
            throw new MarvelException("No se ha podido establecer la conexion",
                    exception);
        }
        return con;
    }
}
