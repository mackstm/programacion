package es.ies.puerto.utilities;

public class TestUtilities {
    public static final String ERR_MSG = "Unexpected Result";
}
