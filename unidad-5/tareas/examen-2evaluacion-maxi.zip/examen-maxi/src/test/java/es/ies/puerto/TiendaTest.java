package es.ies.puerto;

import es.ies.puerto.implementa.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

import java.util.*;

/**
 * Tests para probar tienda y sus productos
 * @author Jose Maximiliano Boada Martin
 */
public class TiendaTest {

    /**
     * Tests de constructor por defecto
     */

    @Test
    public void constructorPorDefectoTestOK() {
        Tienda tienda = new Tienda();
        boolean resultado = tienda.getAlimentos().isEmpty() && tienda.getAparatos().isEmpty() &&
                tienda.getSouvenirMap().isEmpty() && tienda.getProductosCuidado().isEmpty();
        Assertions.assertTrue(resultado, "Resultado inesperado");
    }

    @Test
    public void constructorCompletoTestOK() {
        Alimento alimento1 = new Alimento();
        Alimento alimento2 = new Alimento();

        Aparato aparato1 = new Aparato();
        Aparato aparato2 = new Aparato();

        Souvenir souvenir1 = new Souvenir();
        Souvenir souvenir2 = new Souvenir();

        CuidadoPersonal cuidadoPersonal1 = new CuidadoPersonal();
        CuidadoPersonal cuidadoPersonal2 = new CuidadoPersonal();

        List<Alimento> alimentos = new ArrayList<>(Arrays.asList(alimento1, alimento2));
        Set<Aparato> aparatos = new HashSet<>(Arrays.asList(aparato1, aparato2));
        Map<String, Souvenir> souvenirMap = new HashMap<>();
        souvenirMap.put(souvenir1.getUdi(), souvenir1);
        souvenirMap.put(souvenir2.getUdi(), souvenir2);
        Set<CuidadoPersonal> productosCuidado = new HashSet<>(Arrays.asList(cuidadoPersonal1, cuidadoPersonal2));

        Tienda tienda = new Tienda(alimentos, aparatos, souvenirMap, productosCuidado);
        boolean resultado = tienda.getAlimentos().equals(alimentos) && tienda.getAparatos().equals(aparatos) &&
                tienda.getSouvenirMap().equals(souvenirMap) && tienda.getProductosCuidado().equals(productosCuidado);

        Assertions.assertTrue(resultado,"Resultado inesperado");
    }

    /**
     * Tests de metodos para alimentos
     */

    @Test
    public void agregarAlimentoTestOK() {
        Tienda tienda = new Tienda();
        Alimento alimento = new Alimento("Manzanas",2.50f,"2024-01-09",
                "ALM001","2024-01-15");
        Assertions.assertFalse(tienda.agregarAlimento(alimento), "Resultado inesperado");
    }

    @Test
    public void agregarAlimentoDuplicadoTestOK() {
        Tienda tienda = new Tienda();
        Alimento alimento = new Alimento("Leche",1.99f,"2024-02-09","ALM002"
                ,"2024-02-14");
        tienda.agregarAlimento(alimento);
        Assertions.assertTrue(tienda.agregarAlimento(alimento),"Resultado inesperado");
    }

    @Test
    public void eliminarAlimentoTestOK() {
        Tienda tienda = new Tienda();
        Alimento alimento = new Alimento("Manzanas",2.50f,"2024-01-09",
                "ALM001","2024-01-15");
        tienda.agregarAlimento(alimento);
        Assertions.assertFalse(tienda.eliminarAlimento(alimento),"Resultado inesperado");
    }

    @Test
    public void eliminarAlimentoTestFallido() {
        Tienda tienda = new Tienda();
        Alimento alimento = new Alimento("Manzanas",2.50f,"2024-01-09",
                "ALM001","2024-01-15");
        Assertions.assertTrue(tienda.eliminarAlimento(alimento),"Resultado inesperado");
    }

    @Test
    public void obtenerAlimentoTestOK() {
        Tienda tienda = new Tienda();
        Alimento alimento = new Alimento("Arroz",3.75f,"2024-01-15",
                "ALM003","2024-01-27");
        tienda.agregarAlimento(alimento);
        Assertions.assertEquals(alimento, tienda.obtenerAlimento("ALM003"), "Resultado inesperado");
    }

    @Test
    public void obtenerAlimentoNullTest() {
        Tienda tienda = new Tienda();
        Assertions.assertEquals(null, tienda.obtenerAlimento("Pepe"), "Resultado inesperado");
    }

    /**
     * Tests de metodos para aparatos
     */

    @Test
    public void agregarAparatoTestOK() {
        Tienda tienda = new Tienda();
        Aparato aparato = new Aparato();
        Assertions.assertFalse(tienda.agregarAparato(aparato));
    }

    @Test
    public void agregarAparatoDuplicadoTestOK() {
        Tienda tienda = new Tienda();
        Aparato aparato = new Aparato();
        tienda.agregarAparato(aparato);
        Assertions.assertTrue(tienda.agregarAparato(aparato),"Resultado inesperado");
    }

    @Test
    public void eliminarAparatoTestOK() {
        Tienda tienda = new Tienda();
        Aparato aparato = new Aparato();
        tienda.agregarAparato(aparato);
        Assertions.assertFalse(tienda.eliminarAparato(aparato),"Resultado inesperado");
    }

    @Test
    public void eliminarAparatoTestFallido() {
        Tienda tienda = new Tienda();
        Aparato aparato = new Aparato();
        Assertions.assertTrue(tienda.eliminarAparato(aparato),"Resultado inesperado");
    }

    @Test
    public void obtenerAparatoTestOK() {
        Tienda tienda = new Tienda();
        Aparato aparato = new Aparato("Televisor LED",499.99f,"2024-02-09","APA001");
        tienda.agregarAparato(aparato);
        Assertions.assertEquals(aparato, tienda.obtenerAparato("APA001"), "Resultado inesperado");
    }

    @Test
    public void obtenerAparatoNullTest() {
        Tienda tienda = new Tienda();
        Assertions.assertEquals(null, tienda.obtenerAparato("Pepe"), "Resultado inesperado");
    }
}
